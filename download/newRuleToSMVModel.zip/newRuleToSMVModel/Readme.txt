1.请在application.properties所在的根目录下运行jar包
2.application.properties的配置方式：
	1）JOSN_FILE_DIR是运行时所需的设备的json文档所在的文件夹。
	2）NUSMV_FILE_DIR是安装的NuSMV的位置（需自行下载）
3.工具的参数设置：
	-s :输入的ifttt的文件，必选
	-i: intensity（可设置为0, 1, 2, 3)，必选
	-o: 输出的smv文件所在的文件夹，可选，默认为SMVResult
	-v: NuSMV验证smv文件时输出的反例所在的文件夹，可选，默认为VerificationResult
	例如：java -jar ABC.jar -s Scenerios\User_study.txt -i 0 -o User0\ -v User0_Verification\
4.输入的ifttt文件中可包含一组或多组ifttt规则，每组之间用空格隔开。
5.生成的smv文件为x_y.smv的形式，其中x表示的是输入的ifttt文件中的规则的组数，y取值0，1，2时分别表示U，F，P。生成的反例文件的命名规则同理。