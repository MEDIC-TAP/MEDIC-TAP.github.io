1. Please run jar in the directory where application.properties is located
2. The configuration of application.properties:
	1) JOSN_FILE_DIR is the directory where the json file of the device required is located.
	2) NUSMV_FILE_DIR is the directory where NuSMV is installed.
3. The parameters of MEDIC：
	-s : input ifttt file, required
	-i : intensity（0, 1, 2, 3)，required
	-o : the directory where the smv file is output, optional, the default is SMVResult
	-v : the directory where the counterexample is output when NuSMV verifies the smv file, optional, the default is VerificationResult
	-v : NuSMV验证smv文件时输出的反例所在的文件夹，可选，默认为VerificationResult
	Example：java -jar MEDIC.jar -s Scenerios\User_study.txt -i 0 -o User0\ -v User0_Verification\
4. The input ifttt file can contain one or more groups of ifttt rules, and each group is separated by a space.
5. The generated smv file is in the form of x_y.smv, where x represents the number of rule groups in the input ifttt file, and y values 0, 1, and 2 represent U, F, and P respectively. The naming rules for the generated counterexample files are the same.